import MainPage from './pages/mainPage/mainPage';
import './App.css';

function App() {
  return (
    <div className="App">
     <MainPage/>

    </div>
  );
}

export default App;
