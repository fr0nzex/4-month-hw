function AboutUs (props) {
    return(
        <>
        <h1>Title {props.AboutUs.Title}</h1>
        <h3>teams {props.AboutUs.teams}</h3>
        <h3>winner {props.AboutUs.winner}</h3>
        </>
    )
    }
    
    export default AboutUs;